package jdbc;
import java.sql.SQLException;
import java.util.Scanner;
public class user_input 
{
  public static void main(String[] args)
  {
	  try
	  {
	  
	  Scanner ran = new Scanner(System.in);
	  int inp=1;
	  while(inp==1)
	  {
		  city o = new city();
		 // System.out.println("Test"+inp);
		  if(inp == 1)
			  {
			       System.out.println("Hii Welcome to our page");
				   o.city_you_look();
			  }
			  else
			  {
				  System.out.println("see you soon");
			  }
			  
		  }
	  }
	  catch (Exception e)
	  {
	      System.out.println(e);
	  }
  
  }
}


/*package jdbc;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.applet.Applet;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class cityDAO 
{
	
   public ResultSet displayInfo(String cityname)
   {
	   ResultSet rs =null;
	   try
	   {
		  
	   String query = "Select * from stud";
	   Connection con_obj = psql_server_details.getConnection();
	   Statement stmt = con_obj.createStatement();
	   rs = stmt.executeQuery(query);
	   
	   ResultSetMetaData rsmd = rs.getMetaData();
	   DefaultTableModel model = (DefaultTableModel) tb.getModel();
	   
	   int cols = rsmd.getColumnCount();
	   String[] colname = new String[cols];
	   for(int i=0;i<cols;i++)
	   {
		   colname[i] = rsmd.getColumnName(i+1);
		   model.setColumnIdentifiers(colname);
	   }
	   
		
	   }
	   catch (Exception e)
	      {
	          System.out.println(e.getMessage());
	      }
	  return rs;
	   
	 }
}*/

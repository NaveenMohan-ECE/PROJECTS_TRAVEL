package jdbc;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

public class UI extends JFrame 
{

	private static final long serialVersionUID = 1L;
	protected static final String Sorry = null;
	private JPanel contentPane;
	private JTextField textField;
	private JTable tb;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UI frame = new UI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UI() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin\\Downloads\\trip.jpg"));
		setTitle("Tricky....Trip....");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 584, 433);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter City Name ");
		lblNewLabel.setForeground(new Color(102, 0, 153));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(10, 80, 174, 25);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome to Tricky...Trip");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semilight", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setForeground(new Color(153, 51, 102));
		lblNewLabel_1.setBounds(160, 11, 180, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("You will find information about the city you looking for");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(67, 25, 425, 44);
		contentPane.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(204, 82, 118, 29);
		contentPane.add(textField);
		textField.setColumns(10);
	
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				try
				   {
					
					String txt=textField.getText();
					if(txt != null && txt.trim().length() > 0)
					{
				   String query = "Select * from stud where district ilike '"+txt+"'";
				   Connection con_obj = psql_server_details.getConnection();
				   Statement stmt = con_obj.createStatement();
				   ResultSet rs = stmt.executeQuery(query);
				   
				   ResultSetMetaData rsmd = rs.getMetaData();
				   DefaultTableModel model = (DefaultTableModel) tb.getModel();
				   model.setRowCount(0);
				   
				   int cols = rsmd.getColumnCount();
				   String[] colname = new String[cols];
				   for(int i=0;i<cols;i++)
				   {
					   colname[i] = rsmd.getColumnName(i+1);
					   model.setColumnIdentifiers(colname);
				   }
				   String district,places_to_exolore,cinemas,malls,restaurant,temples;
				   while(rs.next())
				   {
					   district = rs.getString(1);
					   places_to_exolore = rs.getString(2);
					   cinemas= rs.getString(3);
					   malls = rs.getString(4);
					   restaurant = rs.getString(5);
					   temples = rs.getString(6);
					   
					   String[] row = {district,places_to_exolore,cinemas,malls,restaurant,temples};
					   model.addRow(row);
				   }
					
				   }
					
				   }
				   catch (Exception et)
				      {
				          System.out.println(et.getMessage());
				      }
			}
		});
		btnNewButton.setBounds(342, 82, 82, 28);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(45, 143, 475, 227);
		contentPane.add(scrollPane);
		
		tb = new JTable();
		scrollPane.setViewportView(tb);
		
	}
}
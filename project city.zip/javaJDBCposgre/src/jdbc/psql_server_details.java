package jdbc;

import java.sql.*;

public class psql_server_details 
{
	 private static final String url = "jdbc:postgresql://localhost:5433/postgres";
	 private static final String  username= "postgres";
	 private static final String password = "6019";
	 
	 public static Connection getConnection() throws SQLException
	 {
		 return DriverManager.getConnection(url,username,password); 
	 }
	   
}     
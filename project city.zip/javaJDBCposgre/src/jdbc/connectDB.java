package jdbc;
import java.sql.*;

public class connectDB 
{
	public static void readrecord() throws Exception  
	{
		
	}
  public static void main(String[] args)
   {
	   Connection con=connect_to_db("student1","postgres","6019");
	   salem(con,"stud");
   }

private static void salem(Connection con, String string) {
	// TODO Auto-generated method stub
	
}
public static Connection connect_to_db(String dbname, String user, String pass)
{
       Connection con_obj=null;
       String url="jdbc:postgresql://localhost:5433/";
       

       try
       {
           con_obj= DriverManager.getConnection(url+dbname,user,pass);
           if(con_obj!=null)
           {
               System.out.println("Connection established successfully !");
           }
           else
           {
               System.out.println("Connection failed !!");
           }
       }
       catch (Exception e)
       {
           System.out.println(e.getMessage());
       }
       return con_obj;
   }
   
   public static void salem(Connection con,String tName,String uName,int UId)
   {
       Statement stmt;
       ResultSet rs;
       try {
           stmt=con.createStatement();
           String query="select  restaurant from stud";
           rs=stmt.executeQuery(query);

           System.out.println("Top 4 malls");
           System.out.println("---------------------------");
           while(rs.next())
           {
               System.out.print(rs.getString("Hotel"));

           }

       }
       catch (Exception e)
       {
           System.out.println(e.getMessage());
       } 
       
   }
 
}*/

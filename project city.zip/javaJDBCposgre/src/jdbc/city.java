package jdbc;
import java.sql.SQLException;
import java.util.*;
public class city 
{
  String cityname;
  
  void city_you_look()
  {
	  cityDAO obj = new cityDAO();
  try
  {
	  Scanner ran = new Scanner(System.in);
	  System.out.println("Enter the city name : ");
	  cityname = ran.nextLine();
	  obj.displayInfo(cityname);
   }
  catch (Exception e)
      {
          System.out.println(e.getMessage());
      }
   //return  
  }
   
  }
   
